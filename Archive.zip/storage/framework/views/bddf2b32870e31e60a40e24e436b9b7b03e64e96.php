<?php $__env->startSection('content'); ?>

<div class="col-sm-8 blog-main">

	<h1>  Edit: <?php echo $article->title; ?> </h1>


	<hr/>

	<div class="row">


		<?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	





	<?php echo Form::model($article, ['method' => 'PATCH','route' => ['articles.update', $article->id ]]); ?>


		<?php echo $__env->make('articles.form', ['submitButtonText' => 'Update article'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



	<?php echo Form::close(); ?>



	 </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>