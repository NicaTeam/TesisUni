<?php $__env->startSection('content'); ?>

    <div class="col-md-8">

        <h1>Sign in</h1>

        <form method="POST" action="/Login">


            <?php echo e(csrf_field()); ?>



            <div class="form-group">

                <label for="email">Email address:</label>

                <input type="email" class="form-control" id="email" name="email" required>


            </div>



            <div class="form-group">

                <label for="password">Password:</label>

                <input type="password" class="form-control" id="password" name="password" required>


            </div>


            <div class="form-group">



                <button  class="btn btn-primary" >Login</button>


            </div>

            <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        </form>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>