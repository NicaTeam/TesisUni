<?php $__env->startSection('content'); ?>


<?php if($name =='Henry'): ?>

	<h1>This is the about me: <?php echo e($name); ?> <?php echo e($last); ?>, It is working amazing!</h1>

	<p>

		Prueba!



	</p>


	<?php if(count($people)): ?>


	<h3>People I like:</h3>


	<ul>


		<?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<li> <?php echo e($person); ?></li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





	</ul>


	<?php endif; ?>




<?php else: ?>

<h1>Else</h1>



	<?php endif; ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>