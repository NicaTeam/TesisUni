<?php $__env->startSection('content'); ?>

<div class="col-sm-8 blog-main">

	<h1>Write a new article!</h1>


	<hr/>

	<div class="row">


		<div class ="col-lg-6 col-md-6 col-sm-6 col-xs-12">

			<?php if($errors->any()): ?>
	 
			    <ul class="alert alert-danger">

			    

				    	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				    	<li> <?php echo e($error); ?> </li>

				    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			 		

			 	</ul>

		 	<?php endif; ?>

	 	</div>

	 </div>



	<?php echo Form::model($article = new \SalesProgram\Article, ['url' => 'articles']); ?>


	    <?php echo e(csrf_field()); ?>


		<?php echo $__env->make('articles.form', ['submitButtonText' => 'Save Article'] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



	<?php echo Form::close(); ?>


</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>