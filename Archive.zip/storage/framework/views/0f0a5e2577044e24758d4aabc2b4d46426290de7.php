
<div class="form-group">
    <?php echo Form::label('categoryProduct', 'Categoria de Producto:'); ?>

    <select name = 'category_products_id' class ="form-control">
        <?php $__currentLoopData = $categoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <option value="<?php echo e($categoryProduct->id); ?>">

                <?php echo e($categoryProduct->categoria); ?>


            </option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

</div>
<div class="form-group">
    <?php echo Form::label('brandGroup', 'Linea de Puros:'); ?>

    <select name = 'brand_groups_id' class ="form-control">
         <?php $__currentLoopData = $brandGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


             <option value="<?php echo e($brandGroup->id); ?>">

                 <?php echo e($brandGroup->name); ?>


             </option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

</div>


<div class="form-group">
    <?php echo Form::label('unitOfMeasurement', 'Presentation:'); ?>

    <select name = 'unit_of_measurements_id' class ="form-control">
        <?php $__currentLoopData = $unitOfMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitOfMeasurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <option value="<?php echo e($unitOfMeasurement->id); ?>">

                <?php echo e($unitOfMeasurement->name); ?>


            </option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

</div>


<div class="form-group">
    <?php echo Form::label('cigarSize', 'Vitola/Tamano:'); ?>

    <select name = 'cigar_sizes_id' class ="form-control">
        <?php $__currentLoopData = $cigarSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cigarSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <option value="<?php echo e($cigarSize->id); ?>">

                <?php echo e($cigarSize->name); ?>


            </option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

</div>



<div class="form-group">


    <?php echo Form::label('barcode', 'Codigo de Barras:'); ?>


    <?php echo Form::text('barcode', null, ['class' => 'form-control']); ?>



</div>

<div class="form-group">


    <?php echo Form::label('name', 'Nombre:'); ?>


    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>



</div>





<div class="form-group">

    <?php echo Form::label('netWeight', 'Peso Neto gr.:'); ?>

    <?php echo Form::text('netWeight', null, ['class' => 'form-control']); ?>



</div>

<div class="form-group">

    <?php echo Form::label('unitsInPresentation', 'Unidades de presentacion:'); ?>

    <?php echo Form::text('unitsInPresentation', null, ['class' => 'form-control']); ?>



</div>



<div class="form-group">
    <?php echo Form::submit($submitButtonText, ['class'=> 'btn btn-primary form-control']); ?>


</div>

<?php $__env->startSection('footer'); ?>

    <script >

        $('#brandGroup_list').select2({

            placeholder:'Choose a tag'
        });
    </script>



<?php $__env->stopSection(); ?>
