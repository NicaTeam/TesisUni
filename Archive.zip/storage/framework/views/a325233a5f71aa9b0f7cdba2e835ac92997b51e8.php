<div class="form-group <?php echo e($errors->has('categoria') ? 'has-error' : ''); ?>">
    <label for="categoria" class="col-md-4 control-label"><?php echo e('Categoria'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="categoria" type="text" id="categoria" value="<?php echo e(isset($categoryproduct->categoria) ? $categoryproduct->categoria : ''); ?>" >
        <?php echo $errors->first('categoria', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('descripcion') ? 'has-error' : ''); ?>">
    <label for="descripcion" class="col-md-4 control-label"><?php echo e('Descripcion'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="descripcion" type="text" id="descripcion" value="<?php echo e(isset($categoryproduct->descripcion) ? $categoryproduct->descripcion : ''); ?>" >
        <?php echo $errors->first('descripcion', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
