  <div class="blog-masthead">
      <div class="container">
        <nav class="nav blog-nav">
          <a class="nav-link active" href="#">Home</a>
          <a class="nav-link" href="/articles">Articles</a>
          <a class="nav-link" href="#">New features</a>
          

            <a class="nav-link" href="/cigars">Cigars</a>
          <a class="nav-link" href="/about">About</a>

            <?php if(Auth()->check()): ?>

                <a class="nav-link ml-auto" href="#"><?php echo e(Auth::User()->name); ?></a>

            <?php endif; ?>
        </nav>

      </div>
    </div>