<?php $__env->startSection('content'); ?>

<div class="col-sm-8 blog-main">


	<h1> <?php echo e($article->title); ?></h1>


	<article>


		<?php echo e($article->body); ?>


		<?php echo e($article->published_at->diffForHumans()); ?>



	</article>


	<?php if (! ($article->tags->isEmpty())): ?>

		<h5> Tags: </h5>

			<ul>

				<?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<li>

						<?php echo e($tag->name); ?>

					</li>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</ul>
	<?php endif; ?>

	<hr>


	<div class = "comments">



			<div class = "list-group">

				<?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



					<div class = "list-group-item">


							<strong>By: <?php echo e($article->user->name); ?> : &nbsp; </strong>
						<?php echo e($comment->body); ?> <?php echo e($comment->created_at->diffForHumans()); ?>




					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</div>






	</div>

	<hr>

	<div class = "card">


		<div class="card-block">

			<form method="POST" action="/articles/<?php echo e($article->id); ?>/comments">


				<?php echo e(csrf_field()); ?>


				<div class = "form-group">

					<textarea name ="body"  placeholder="Your comment here!" class ="form-control" required> </textarea>
				</div>

				<div class = "form-group">

					<button type="submit" class = "btn btn-primary">Add Comment</button>
				</div>


			</form>

			<?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>