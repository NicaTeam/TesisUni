<!doctype <html>

<html lang="en">

<head>

	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<h1>This is the about page!</h1>

</body>
</html>