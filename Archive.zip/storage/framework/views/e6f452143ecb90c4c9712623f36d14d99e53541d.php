<?php $__env->startSection('content'); ?>



<h1>Hola soy Junior Torrez, Y esta es mi pagina personal.</h1>

<h2>Bienvenidos!</h2>

<img src="imagenes/1979522_589130214517150_1374237228_n.jpg">



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>