<div class="form-group <?php echo e($errors->has('Name') ? 'has-error' : ''); ?>">
    <label for="Name" class="col-md-4 control-label"><?php echo e('Name'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="Name" type="text" id="Name" value="<?php echo e(isset($bonchero->Name) ? $bonchero->Name : ''); ?>" >
        <?php echo $errors->first('Name', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('lastName') ? 'has-error' : ''); ?>">
    <label for="lastName" class="col-md-4 control-label"><?php echo e('Lastname'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="lastName" type="text" id="lastName" value="<?php echo e(isset($bonchero->lastName) ? $bonchero->lastName : ''); ?>" >
        <?php echo $errors->first('lastName', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <label for="email" class="col-md-4 control-label"><?php echo e('Email'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="email" type="text" id="email" value="<?php echo e(isset($bonchero->email) ? $bonchero->email : ''); ?>" >
        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('phone_Number') ? 'has-error' : ''); ?>">
    <label for="phone_Number" class="col-md-4 control-label"><?php echo e('Phone Number'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="phone_Number" type="text" id="phone_Number" value="<?php echo e(isset($bonchero->phone_Number) ? $bonchero->phone_Number : ''); ?>" >
        <?php echo $errors->first('phone_Number', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
