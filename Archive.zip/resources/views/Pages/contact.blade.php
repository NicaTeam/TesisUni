@extends('app')

@section('content')

	<h1>Contact me!</h1>

@endsection


@section('footer')

	<script type="text/javascript">

		alert('Contact form scripts');

	</script>

@endsection