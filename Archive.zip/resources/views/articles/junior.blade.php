@extends('Master')


@section('content')



<h1>Hola soy Junior Torrez, Y esta es mi pagina personal.</h1>

<h2>Bienvenidos!</h2>

<img src="imagenes/1979522_589130214517150_1374237228_n.jpg">



@endsection