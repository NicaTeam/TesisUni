<?php

namespace SalesProgram\Http\Controllers;

use Illuminate\Http\Request;
use SalesProgram\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use SalesProgram\Article;
use SalesProgram\Http\Requests\ArticleFormRequest;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Auth;



class ArticlesController extends Controller
{


    public function __construct(){



        $this->middleware('auth', ['only' => 'create']);
        //$this->middleware('auth', ['except' => 'index']);

    }
    public function index(){


    	//$articles = DB::table('articles')->latest()->get();


        $articles = Article::latest('published_at')->Published()->get();


    	//return view('Pages.articles', compact('articles'));

    	return view('Pages.articles')->with('articles', $articles);



    }


    public function show($id){

      

    	$article = Article::findOrFail($id);


        //dd($article->published_at->diffForHumans());


    	return view('Articles.show', compact('article'));

    }


    public function create(){


    	return view('Articles.create');
    }


    public function store(ArticleFormRequest $request){


        //$article = new Article;

        //$article->title = $request->get('title');
        //$article->body= $request->get('body');
        //$article->published_at=$request->get('published_at');

        //$article->published_at= Carbon::now();

        //$article->save();

        //Article::create($request->all());

        //$article = new Article($request->all());

        //Auth::User()->articles()->save($article);

        Auth::user()->articles()->create($request->all());

        flash()->overlay('Your article has been created!', 'Good Job');



        return Redirect::to('articles');

    }




    public function edit($id){


        $article = Article::findOrFail($id);

        return view('Articles.edit', compact('article'));


    }


     public function update($id, ArticleFormRequest $request){



       $article = Article::findOrFail($id);

       $article->update($request->all());



       return Redirect::to('articles');


    }

    public function junior(){


        return view('Articles.junior');
    }
}
