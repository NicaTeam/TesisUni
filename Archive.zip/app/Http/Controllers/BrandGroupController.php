<?php

namespace SalesProgram\Http\Controllers;

use Illuminate\Http\Request;

class BrandGroupController extends Controller
{
    //
}
